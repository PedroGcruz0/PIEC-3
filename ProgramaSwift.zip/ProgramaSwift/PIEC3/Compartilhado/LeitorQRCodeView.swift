//
//  LeitorQRCodeView.swift
//  PIEC3
//
//  Created by Pedro Gabriel de Carvalho Cruz on 19/11/25.
//

import SwiftUI
import AVFoundation

struct LeitorQRCodeView: UIViewRepresentable {
    
    /// Callback com o texto lido do QR Code
    let aoLerCodigo: (String) -> Void
    
    func makeCoordinator() -> Coordenador {
        Coordenador(parent: self)
    }
    
    func makeUIView(context: Context) -> UIView {
        let view = UIView(frame: .zero)
        
        let sessao = AVCaptureSession()
        
        guard let dispositivo = AVCaptureDevice.default(for: .video),
              let entrada = try? AVCaptureDeviceInput(device: dispositivo),
              sessao.canAddInput(entrada) else {
            return view
        }
        sessao.addInput(entrada)
        
        let saida = AVCaptureMetadataOutput()
        guard sessao.canAddOutput(saida) else {
            return view
        }
        sessao.addOutput(saida)
        
        saida.setMetadataObjectsDelegate(context.coordinator, queue: .main)
        saida.metadataObjectTypes = [.qr]
        
        let previewLayer = AVCaptureVideoPreviewLayer(session: sessao)
        previewLayer.videoGravity = .resizeAspectFill
        previewLayer.frame = UIScreen.main.bounds
        view.layer.addSublayer(previewLayer)
        
        context.coordinator.sessao = sessao
        context.coordinator.previewLayer = previewLayer
        
        sessao.startRunning()
        
        return view
    }
    
    func updateUIView(_ uiView: UIView, context: Context) {}
    
    // MARK: - Coordenador
    
    final class Coordenador: NSObject, AVCaptureMetadataOutputObjectsDelegate {
        let parent: LeitorQRCodeView
        var sessao: AVCaptureSession?
        var previewLayer: AVCaptureVideoPreviewLayer?
        
        init(parent: LeitorQRCodeView) {
            self.parent = parent
        }
        
        func metadataOutput(_ output: AVCaptureMetadataOutput,
                            didOutput metadataObjects: [AVMetadataObject],
                            from connection: AVCaptureConnection) {
            guard let objeto = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
                  let valor = objeto.stringValue else { return }
            
            sessao?.stopRunning()
            parent.aoLerCodigo(valor)
        }
    }
}
