//
//  AlunoView.swift
//  PIEC3
//
//  Created by Pedro Gabriel de Carvalho Cruz on 19/11/25.
//

import SwiftUI

struct StudentView: View {
    @State private var showingQRScanner = false
    @State private var statusMessage: String?
    @State private var isLoading = false

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Text("Área do Aluno")
                    .font(.largeTitle)
                    .bold()

                Text("Aqui você será capaz de marcar sua presença.")
                    .multilineTextAlignment(.center)

                Button {
                    showingQRScanner = true
                } label: {
                    HStack {
                        Image(systemName: "qrcode.viewfinder")
                        Text("Marcar presença por QR Code")
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                }
                .buttonStyle(.borderedProminent)

                Button {
                    // Aqui entra lógica de NFC (passo 7)
                } label: {
                    HStack {
                        Image(systemName: "wave.3.right")
                        Text("Marcar presença por NFC")
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                }
                .buttonStyle(.bordered)

                if isLoading {
                    ProgressView("Enviando presença...")
                }

                if let statusMessage {
                    Text(statusMessage)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                }

                Spacer()
            }
            .padding()
        }
        .sheet(isPresented: $showingQRScanner) {
            QRScannerView { result in
                showingQRScanner = false
                registrarPresenca(qrcode: result)
            }
        }
    }

    private func registrarPresenca(qrcode: String) {
        isLoading = true
        statusMessage = nil

        Task {
            do {
                let id = try await UserRepository.shared.registrarPresencaQRCode(qrcode: qrcode)
                await MainActor.run {
                    isLoading = false
                    statusMessage = "Presença registrada com sucesso (id: \(id))."
                }
            } catch {
                await MainActor.run {
                    isLoading = false
                    statusMessage = "Erro ao registrar presença: \(error.localizedDescription)"
                }
            }
        }
    }
}
