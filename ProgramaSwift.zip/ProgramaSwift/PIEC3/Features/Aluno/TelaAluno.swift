import SwiftUI

struct TelaAluno: View {
    @EnvironmentObject var sessaoVM: SessaoViewModel
    
    private let turmas = [
        "Engenharia de Software",
        "Arquitetura de Computadores",
        "Algoritmos e Estrutura de Dados"
    ]
    
    @State private var turmaSelecionada: String?
    @State private var mostrandoLeitorQRCode = false
    
    // texto embaixo da lista (opcional, pode tirar se quiser)
    @State private var mensagemStatus: String?
    
    // estados para o ALERTA
    @State private var mostrarAlertaPresenca = false
    @State private var mensagemAlerta = ""
    
    var body: some View {
        NavigationStack {
            VStack {
                List {
                    Section("Turmas") {
                        ForEach(turmas, id: \.self) { turma in
                            HStack {
                                Text(turma)
                                Spacer()
                                Button {
                                    turmaSelecionada = turma
                                    mensagemStatus = nil
                                    mostrandoLeitorQRCode = true
                                } label: {
                                    Image(systemName: "chevron.right")
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                
                if let mensagemStatus {
                    Text(mensagemStatus)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .padding(.bottom, 8)
                }
            }
            .navigationTitle("Aluno")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Sair") {
                        sessaoVM.logout()
                    }
                }
            }
        }
        .sheet(isPresented: $mostrandoLeitorQRCode) {
            #if targetEnvironment(simulator)
            // Simulador: não tem câmera, então mostramos uma tela de simulação
            VStack(spacing: 16) {
                Text("Leitor de QR Code")
                    .font(.title2)
                    .bold()
                Text("No simulador não há câmera.\nUse um iPhone real para testar o scan,\nou clique abaixo para simular.")
                    .multilineTextAlignment(.center)
                    .foregroundColor(.secondary)
                    .padding()
                
                Button("Simular leitura e confirmar presença") {
                    mostrandoLeitorQRCode = false
                    let nomeTurma = turmaSelecionada ?? "turma"
                    mensagemStatus = "Presença confirmada para \(nomeTurma). (simulado)"
                    
                    mensagemAlerta = "Presença confirmada para \(nomeTurma)."
                    mostrarAlertaPresenca = true
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            #else
            // iPhone real: abre câmera de verdade
            LeitorQRCodeView { _ in
                mostrandoLeitorQRCode = false
                let nomeTurma = turmaSelecionada ?? "turma"
                mensagemStatus = "Presença confirmada para \(nomeTurma)."
                
                mensagemAlerta = "Presença confirmada para \(nomeTurma)."
                mostrarAlertaPresenca = true
            }
            #endif
        }
        .alert("Presença confirmada", isPresented: $mostrarAlertaPresenca) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(mensagemAlerta)
        }
    }
}

