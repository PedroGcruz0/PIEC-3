import SwiftUI

struct TelaLogin: View {
    @EnvironmentObject var sessaoVM: SessaoViewModel
    
    @State private var email: String = ""
    @State private var senha: String = ""
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Spacer()
                
                // Título / logo (ajuste o texto conforme o app original)
                Text("Programa de Chamada")
                    .font(.largeTitle)
                    .bold()
                
                Text("Faça login para continuar")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                VStack(alignment: .leading, spacing: 16) {
                    Text("E-mail")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    TextField("Digite seu E-mail aqui", text: $email)
                        .keyboardType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(8)
                    
                    Text("Senha")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    SecureField("••••••••", text: $senha)
                        .padding()
                        .background(Color(.secondarySystemBackground))
                        .cornerRadius(8)
                }
                .padding(.horizontal)
                
                if let erro = sessaoVM.erro {
                    Text(erro)
                        .foregroundColor(.red)
                        .font(.footnote)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                
                Button {
                    Task {
                        await sessaoVM.login(email: email, senha: senha)
                    }
                } label: {
                    HStack {
                        if sessaoVM.carregando {
                            ProgressView()
                                .tint(.white)
                        } else {
                            Text("Entrar")
                                .bold()
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background((email.isEmpty || senha.isEmpty) ? Color.gray : Color.accentColor)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal)
                }
                .disabled(sessaoVM.carregando || email.isEmpty || senha.isEmpty)
                
                Spacer()
            }
        }
    }
}

