//
//  ProfessorView.swift
//  PIEC3
//
//  Created by Pedro Gabriel de Carvalho Cruz on 19/11/25.
//

import SwiftUI
import CoreImage
import CoreImage.CIFilterBuiltins

struct ProfessorView: View {
    @State private var aulaId: String = ""
    @State private var qrCodeString: String?
    @State private var qrImage: UIImage?
    @State private var isLoading = false
    @State private var statusMessage: String?

    private let context = CIContext()
    private let qrFilter = CIFilter.qrCodeGenerator()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    Text("Área do Professor")
                        .font(.largeTitle)
                        .bold()

                    Text("Bem-vindo, Professor! Aqui você poderá gerar o QR Code da chamada e gerenciar sua turma.")
                        .multilineTextAlignment(.center)

                    TextField("ID da aula", text: $aulaId)
                        .textFieldStyle(.roundedBorder)
                        .keyboardType(.default)

                    Button {
                        gerarQRCode()
                    } label: {
                        HStack {
                            Image(systemName: "qrcode")
                            Text("Gerar QR Code para chamada")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(aulaId.isEmpty)

                    if isLoading {
                        ProgressView("Gerando QR Code...")
                    }

                    if let img = qrImage {
                        Image(uiImage: img)
                            .resizable()
                            .interpolation(.none)
                            .scaledToFit()
                            .frame(width: 200, height: 200)
                            .padding()
                    }

                    Button {
                        // lógica NFC para professor (passo 7)
                    } label: {
                        HStack {
                            Image(systemName: "wave.3.right")
                            Text("Fazer chamada por NFC")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                    }
                    .buttonStyle(.bordered)

                    Button {
                        // navegação para tela de Gerenciar Turma
                    } label: {
                        HStack {
                            Text("Gerenciar Turma")
                            Spacer()
                            Image(systemName: "chevron.right")
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                    }
                    .buttonStyle(.bordered)

                    if let statusMessage {
                        Text(statusMessage)
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                    }

                    Spacer()
                }
                .padding()
            }
        }
    }

    private func gerarQRCode() {
        isLoading = true
        statusMessage = nil
        qrImage = nil

        Task {
            do {
                let qrString = try await UserRepository.shared.gerarQRCodeAula(aulaId: aulaId)
                await MainActor.run {
                    self.qrCodeString = qrString
                    self.qrImage = qrString.flatMap { generateQRCode(from: $0) }
                    self.isLoading = false
                    self.statusMessage = qrString == nil
                        ? "Backend não retornou o QR Code."
                        : "QR Code gerado com sucesso."
                }
            } catch {
                await MainActor.run {
                    self.isLoading = false
                    self.statusMessage = "Erro ao gerar QR Code: \(error.localizedDescription)"
                }
            }
        }
    }

    private func generateQRCode(from string: String) -> UIImage? {
        let data = Data(string.utf8)
        qrFilter.setValue(data, forKey: "inputMessage")
        qrFilter.setValue("M", forKey: "inputCorrectionLevel")

        guard let outputImage = qrFilter.outputImage else { return nil }

        let transform = CGAffineTransform(scaleX: 10, y: 10)
        let scaledImage = outputImage.transformed(by: transform)

        if let cgImage = context.createCGImage(scaledImage, from: scaledImage.extent) {
            return UIImage(cgImage: cgImage)
        } else {
            return nil
        }
    }
}
