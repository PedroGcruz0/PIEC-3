import SwiftUI
import CoreImage
import CoreImage.CIFilterBuiltins

struct TelaProfessor: View {
    @EnvironmentObject var sessaoVM: SessaoViewModel
    
    private let turmas = [
        "Engenharia de Software",
        "Arquitetura de Computadores",
        "Algoritmos e Estrutura de Dados"
    ]
    
    @State private var turmaSelecionada: String?
    @State private var qrImage: UIImage?
    @State private var mostrandoQR = false
    
    private let contexto = CIContext()
    private let filtroQR = CIFilter.qrCodeGenerator()
    
    var body: some View {
        NavigationStack {
            List {
                Section("Turmas") {
                    ForEach(turmas, id: \.self) { turma in
                        HStack {
                            Text(turma)
                            Spacer()
                            Button {
                                gerarQRCodePara(turma: turma)
                            } label: {
                                Image(systemName: "chevron.right")
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }
            }
            .navigationTitle("Professor")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Sair") {
                        sessaoVM.logout()
                    }
                }
            }
        }
        .sheet(isPresented: $mostrandoQR) {
            VStack(spacing: 16) {
                Text(turmaSelecionada ?? "")
                    .font(.headline)
                
                if let imagem = qrImage {
                    Image(uiImage: imagem)
                        .resizable()
                        .interpolation(.none)
                        .scaledToFit()
                        .frame(width: 220, height: 220)
                } else {
                    Text("Não foi possível gerar o QR Code.")
                        .foregroundColor(.secondary)
                }
                
                Button("Fechar") {
                    mostrandoQR = false
                }
                .padding(.top, 16)
            }
            .padding()
        }
    }
    
    private func gerarQRCodePara(turma: String) {
        turmaSelecionada = turma
        
        // Conteúdo do QR só para prototipagem:
        let texto = "PRESENCA:\(turma)"
        
        let dados = Data(texto.utf8)
        filtroQR.setValue(dados, forKey: "inputMessage")
        filtroQR.setValue("M", forKey: "inputCorrectionLevel")
        
        if let output = filtroQR.outputImage {
            let transform = CGAffineTransform(scaleX: 10, y: 10)
            let imagemEscalada = output.transformed(by: transform)
            
            if let cgImage = contexto.createCGImage(imagemEscalada, from: imagemEscalada.extent) {
                qrImage = UIImage(cgImage: cgImage)
            } else {
                qrImage = nil
            }
        } else {
            qrImage = nil
        }
        
        mostrandoQR = true
    }
}

