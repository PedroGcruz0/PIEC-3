import Foundation
import Combine

enum PerfilUsuario {
    case aluno
    case professor
}

final class SessaoViewModel: ObservableObject {
    @Published var perfil: PerfilUsuario? = nil
    @Published var carregando: Bool = false
    @Published var erro: String? = nil
    
    func login(email: String, senha: String) {
        carregando = true
        erro = nil
        
        defer { carregando = false }
        
        let emailLower = email.lowercased()
        
        if emailLower == "waldemar@waldemar.com" && senha == "123" {
            perfil = .professor
        } else if emailLower == "aluno@aluno.com" && senha == "123" {
            perfil = .aluno
        } else {
            perfil = nil
            erro = "Credenciais inválidas."
        }
    }
    
    func logout() {
        perfil = nil
        erro = nil
    }
}

