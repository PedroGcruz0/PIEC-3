import SwiftUI

@main
struct PIEC3AppApp: App {
    @StateObject private var sessaoVM = SessaoViewModel()
    
    var body: some Scene {
        WindowGroup {
            ConteudoPrincipal()
                .environmentObject(sessaoVM)
        }
    }
}

struct ConteudoPrincipal: View {
    @EnvironmentObject var sessaoVM: SessaoViewModel
    
    var body: some View {
        Group {
            if let perfil = sessaoVM.perfil {
                switch perfil {
                case .aluno:
                    TelaAluno()
                case .professor:
                    TelaProfessor()
                }
            } else {
                TelaLogin()
            }
        }
    }
}

