import Foundation

struct GraphQLClient {
    
    static let shared = GraphQLClient()
    
    // Endpoint do AppSync (do teu projeto Android)
    private let endpointURL: URL = URL(
        string: "https://2umok2mglrdejaxw6uobw53rse.appsync-api.us-east-2.amazonaws.com/graphql"
    )!
    
    enum GraphQLError: Error {
        case invalidStatusCode
        case emptyResponse
    }
    
    func execute(query: String) async throws -> Data {
        var request = URLRequest(url: endpointURL)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        // No Android, a autenticação é IAM (via Amplify).
        // No iOS, se você não configurar Amplify/assinatura IAM,
        // essa chamada vai falhar com 401/403.
        // Por enquanto, deixamos SEM cabeçalho de auth:
        // request.setValue("x-api-key", forHTTPHeaderField: ...)  // NÃO USAR
        
        let body: [String: Any] = ["query": query]
        request.httpBody = try JSONSerialization.data(withJSONObject: body, options: [])
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let http = response as? HTTPURLResponse,
              200..<300 ~= http.statusCode else {
            throw GraphQLError.invalidStatusCode
        }
        
        guard !data.isEmpty else {
            throw GraphQLError.emptyResponse
        }
        
        return data
    }
}

