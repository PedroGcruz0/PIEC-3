//
//  LeitorNFC.swift
//  PIEC3
//
//  Created by Pedro Gabriel de Carvalho Cruz on 19/11/25.
//

import Foundation
import CoreNFC

/// Responsável por iniciar e gerenciar a leitura NFC (tags NDEF)
final class LeitorNFC: NSObject, NFCNDEFReaderSessionDelegate {
    
    private var sessao: NFCNDEFReaderSession?
    
    /// Callback chamado quando uma mensagem é lida com sucesso
    var aoLerMensagem: ((String) -> Void)?
    
    /// Inicia a leitura NFC
    func iniciarLeitura() {
        guard NFCNDEFReaderSession.readingAvailable else {
            print("NFC não está disponível neste dispositivo.")
            return
        }
        
        // invalidateAfterFirstRead = true → encerra após ler uma tag
        sessao = NFCNDEFReaderSession(
            delegate: self,
            queue: nil,
            invalidateAfterFirstRead: true
        )
        
        sessao?.alertMessage = "Aproxime o cartão/etiqueta NFC para marcar presença."
        sessao?.begin()
    }
    
    /// Invalida/encerra a sessão manualmente (se precisar)
    func encerrar() {
        sessao?.invalidate()
        sessao = nil
    }
    
    // MARK: - NFCNDEFReaderSessionDelegate
    
    func readerSession(_ session: NFCNDEFReaderSession,
                       didInvalidateWithError error: Error) {
        print("Sessão NFC encerrada: \(error.localizedDescription)")
    }
    
    func readerSession(_ session: NFCNDEFReaderSession,
                       didDetectNDEFs messages: [NFCNDEFMessage]) {
        guard
            let mensagem = messages.first,
            let registro = mensagem.records.first
        else { return }
        
        let dados = registro.payload
        
        // Em muitos casos o primeiro byte pode ser idioma, etc.
        // Se o backend gravar puro UTF-8, isso funciona direto:
        if let texto = String(data: dados, encoding: .utf8) {
            aoLerMensagem?(texto)
        }
    }
}

