import Foundation

/// Repositório responsável por operações do usuário relacionadas à presença e login
final class UsuarioRepositorio {
    
    static let shared = UsuarioRepositorio()
    
    private let client = GraphQLClient.shared
    
    enum RepoError: Error {
        case formatoInvalido
    }
    
    /// Registra presença usando a string do QRCode lida pelo app
    @discardableResult
    func registrarPresencaQRCode(qrcode: String) async throws -> String {
        let mutation = """
        mutation RegistrarPresenca {
          registrarPresencaQRCode(qrcode: "\(qrcode)") {
            id
            alunoEmail
            presente
            tipo
          }
        }
        """
        
        let data = try await client.execute(query: mutation)
        
        let jsonAny = try JSONSerialization.jsonObject(with: data, options: [])
        guard let json = jsonAny as? [String: Any] else {
            throw RepoError.formatoInvalido
        }
        
        let root = (json["data"] as? [String: Any]) ?? json
        
        guard
            let presenca = root["registrarPresencaQRCode"] as? [String: Any],
            let id = presenca["id"] as? String
        else {
            throw RepoError.formatoInvalido
        }
        
        return id
    }
    
    /// Gera (no backend) uma string que será usada para montar o QRCode da aula
    func gerarQRCodeAula(aulaId: String) async throws -> String? {
        let mutation = """
        mutation GerarQRCode {
          gerarQRCodeAula(aulaId: "\(aulaId)")
        }
        """
        
        let data = try await client.execute(query: mutation)
        
        let jsonAny = try JSONSerialization.jsonObject(with: data, options: [])
        guard let json = jsonAny as? [String: Any] else {
            throw RepoError.formatoInvalido
        }
        
        let root = (json["data"] as? [String: Any]) ?? json
        
        let qrString = root["gerarQRCodeAula"] as? String
        return qrString
    }
    
    /// Faz login e devolve o tipo de usuário ("aluno" ou "professor")
    func login(email: String, senha: String) async throws -> String {
        let mutation = """
        mutation Login {
          login(email: "\(email)", senha: "\(senha)") {
            tipoUsuario
          }
        }
        """
        
        let data = try await client.execute(query: mutation)
        
        let jsonAny = try JSONSerialization.jsonObject(with: data, options: [])
        guard let json = jsonAny as? [String: Any] else {
            throw RepoError.formatoInvalido
        }
        
        let root = (json["data"] as? [String: Any]) ?? json
        
        guard
            let login = root["login"] as? [String: Any],
            let tipo = login["tipoUsuario"] as? String
        else {
            throw RepoError.formatoInvalido
        }
        
        return tipo   // "aluno" ou "professor"
    }
}

